export const frontEndBoosts = [
  {
    id: 1,
    title: "Бабл гам",
    power: 1,
    image: "https://i.ibb.co/MByxY7V/icon-boost-1.png",
  },
  {
    id: 2,
    title: "Буба-Буба",
    power: 8,
    image: "https://i.ibb.co/sW1b7hy/icon-boost-2.png",
  },
  {
    id: 3,
    title: "Мега Пузыри",
    power: 20,
    image:
      "https://i.ibb.co/hX68f3S/realistic-transparent-3d-bubbles-underwater-soap-bubbles-vector-illustration-png.webp",
  },
  {
    id: 4,
    title: "Вселенная пузырей",
    power: 80,
    image: "https://i.ibb.co/CwvgrWJ/icon.png",
  },
  {
    id: 5,
    title: "Мультивселенная",
    power: 100,
    image: "https://i.ibb.co/CwvgrWJ/icon.png",
  },
  {
    id: 6,
    title: "Вселенная Марвел",
    power: 200,
    image:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b9/Captain_America%27s_shield.svg/274px-Captain_America%27s_shield.svg.png",
  },
  {
    id: 7,
    title: "Галактика поп-итов",
    power: 1000,
    image:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b9/Captain_America%27s_shield.svg/274px-Captain_America%27s_shield.svg.png",
  },
];
